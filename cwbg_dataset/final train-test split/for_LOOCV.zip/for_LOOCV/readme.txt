these foldes contain experiment folders as well.
they have the accurate tfrecords. 
 - the ones with not just (features, labels) but     (features,labels,names) where names is like (as an example ) Soo1c002p012r02a12.skeleton
 - this is needed for child selection in LOOCV implementations


update---
for similar and share , I have done the implementations on 2023/3/11, no experimental folder.
results are there in the same way.