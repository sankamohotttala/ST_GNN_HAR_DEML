import pickle

objects = []
file=r'F:\Codes\joint attention\2022\visualize_vattu_child\save_directory\xsub\train_label.pkl'
with (open(file, "rb")) as openfile:
    while True:
        try:
            objects.append(pickle.load(openfile))
        except EOFError:
            break
print(objects)