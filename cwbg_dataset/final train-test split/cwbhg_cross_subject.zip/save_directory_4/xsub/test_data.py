#load a pickle file
import pickle
import numpy as np

#load the data
with open('train_label.pkl', 'rb') as f:
    data = pickle.load(f)
#load numpy data
data_np = np.load('train_data_joint.npy')
a=1